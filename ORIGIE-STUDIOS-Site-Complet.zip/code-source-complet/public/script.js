const menuButton=document.querySelector('.menu-toggle');
const nav=document.querySelector('#nav');
menuButton?.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuButton.setAttribute('aria-expanded',String(open));menuButton.setAttribute('aria-label',open?'Fermer le menu':'Ouvrir le menu');});
nav?.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuButton?.setAttribute('aria-expanded','false');}));
document.querySelector('#year').textContent=new Date().getFullYear();
const toast=document.querySelector('#toast');let toastTimer;
function notify(message){toast.textContent=message;toast.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.classList.remove('show'),3000)}
async function share(title,id){const url=new URL(id?'#'+id:window.location.pathname,window.location.href).href;try{if(navigator.share){await navigator.share({title,url});return}if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(url);notify('Lien copié !');return}window.prompt('Copiez ce lien :',url)}catch(err){if(err.name!=='AbortError')window.prompt('Copiez ce lien :',url)}}
document.querySelectorAll('[data-share]').forEach(button=>button.addEventListener('click',()=>share(button.dataset.title,button.dataset.share)));
document.querySelector('#share-site')?.addEventListener('click',()=>share('ORIGIE STUDIOS'));

// Decorative video is silent; respect reduced motion and save-data preferences.
(()=>{const video=document.getElementById('hero-video');const button=document.getElementById('video-toggle');if(!video||!button)return;
const reduced=window.matchMedia('(prefers-reduced-motion: reduce)');let userPaused=false;let loaded=false;
function sync(){button.textContent=video.paused?'Lire l’animation':'Pause animation';button.setAttribute('aria-label',video.paused?'Lire l’animation de fond':'Mettre l’animation de fond en pause')}
async function start(){if(!loaded){video.src=video.dataset.src;video.load();loaded=true}video.muted=true;try{await video.play()}catch{sync()}}
video.addEventListener('playing',()=>{video.classList.add('is-ready');sync()});video.addEventListener('pause',sync);video.addEventListener('error',()=>{video.classList.remove('is-ready');button.hidden=true});
button.hidden=false;button.addEventListener('click',()=>{if(video.paused){userPaused=false;start()}else{userPaused=true;video.pause()}});
reduced.addEventListener('change',()=>{if(reduced.matches)video.pause();else if(!userPaused)start()});
document.addEventListener('visibilitychange',()=>{if(document.hidden)video.pause();else if(!userPaused&&!reduced.matches&&!navigator.connection?.saveData)start()});
if(!reduced.matches&&!navigator.connection?.saveData)start();
})();
