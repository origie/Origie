import {env} from "cloudflare:workers";
import {stats} from "../../../../lib/analytics-core.mjs";
export const dynamic="force-dynamic";
export async function GET(request:Request){try{return await stats(request,env)}catch{return Response.json({error:"Service temporairement indisponible"},{status:503,headers:{"Cache-Control":"no-store"}})}}
