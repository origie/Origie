import {env} from "cloudflare:workers";
import {collect} from "../../../../lib/analytics-core.mjs";
export const dynamic="force-dynamic";
export async function POST(request:Request){try{return await collect(request,env)}catch{return Response.json({error:"Service temporairement indisponible"},{status:503,headers:{"Cache-Control":"no-store"}})}}
