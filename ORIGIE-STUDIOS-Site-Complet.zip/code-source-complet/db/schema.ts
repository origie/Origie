import {sqliteTable,text,integer,index} from 'drizzle-orm/sqlite-core';
export const sessions=sqliteTable('analytics_sessions',{
 id:text('id').primaryKey(),startedAt:integer('started_at').notNull(),lastSeen:integer('last_seen').notNull(),source:text('source').notNull(),device:text('device').notNull(),browser:text('browser').notNull(),os:text('os').notNull(),landing:text('landing').notNull()
},t=>[index('sessions_last_seen').on(t.lastSeen),index('sessions_started_at').on(t.startedAt)]);
export const events=sqliteTable('analytics_events',{
 id:text('id').primaryKey(),sessionId:text('session_id').notNull(),at:integer('at').notNull(),kind:text('kind').notNull(),page:text('page').notNull(),action:text('action').notNull()
},t=>[index('events_at').on(t.at),index('events_session').on(t.sessionId)]);
