CREATE TABLE `analytics_events` (
	`id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`at` integer NOT NULL,
	`kind` text NOT NULL,
	`page` text NOT NULL,
	`action` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `events_at` ON `analytics_events` (`at`);--> statement-breakpoint
CREATE INDEX `events_session` ON `analytics_events` (`session_id`);--> statement-breakpoint
CREATE TABLE `analytics_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`started_at` integer NOT NULL,
	`last_seen` integer NOT NULL,
	`source` text NOT NULL,
	`device` text NOT NULL,
	`browser` text NOT NULL,
	`os` text NOT NULL,
	`landing` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `sessions_last_seen` ON `analytics_sessions` (`last_seen`);--> statement-breakpoint
CREATE INDEX `sessions_started_at` ON `analytics_sessions` (`started_at`);