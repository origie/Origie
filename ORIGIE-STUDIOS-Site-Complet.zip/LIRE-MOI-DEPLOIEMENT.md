# ORIGIE STUDIOS — Export complet du site principal

Export du 18 octobre 2026, version 7.
Site : https://origie-studios.josephmunsi.chatgpt.site/
Révision source : b4abeba0ea2468530e6433d6ba44bc1e4cc8da27

## Contenu de l’archive

- `site-a-deployer/` : les fichiers publics exacts du site : accueil, documentation, conditions d’utilisation, feuilles de style, scripts, images et vidéo.
- `code-source-complet/` : l’intégralité des fichiers suivis du projet, y compris les fichiers publics, les API de statistiques, le schéma de base de données, les migrations SQL, les dépendances verrouillées et la configuration de construction.
- `INVENTAIRE.json` : noms, tailles et empreintes SHA-256 des fichiers exportés.

## Déployer la partie visuelle sur un hébergement statique

1. Décompresser ce ZIP.
2. Importer le CONTENU de `site-a-deployer/` dans la racine publique de votre hébergement. `index.html` doit se trouver directement dans cette racine.
3. Conserver le dossier `assets/` et tous les fichiers CSS/JS à leur place. Il n’y a aucune compilation à effectuer pour cette partie.
4. Publier le site à la racine du domaine (exemple : https://votre-domaine.com/). Les liens commençant par `/` supposent une installation à la racine, pas dans un sous-dossier.
5. Dans `index.html`, remplacer les anciennes adresses absolues des balises `canonical`, `og:url` et `og:image` par celles de votre domaine.
6. Adapter les informations d’hébergement des conditions d’utilisation au nouvel hébergeur.

La vidéo de fond est fournie en MP4, pas seulement sous forme de lien. Les scripts existants gèrent sa lecture en boucle et tiennent compte des préférences de réduction des animations. L’autoplay reste soumis aux règles du navigateur.

IMPORTANT : déposer uniquement les fichiers statiques affiche le site et ses médias, mais ne crée pas les API `/api/analytics/*`. Le bandeau de consentement demeure présent dans cette copie fidèle ; les statistiques ne fonctionneront pas tant que leur serveur n’est pas configuré. En cas de déploiement strictement statique, retirer les inclusions de `analytics.js` et les boutons `data-audience-preferences` des trois pages, puis adapter la notice d’audience. Le code complet d’origine reste disponible dans le dossier suivant.

## Conserver également le serveur des statistiques

Le projet utilise Vinext/Vite et Cloudflare Workers, avec une base Cloudflare D1 liée sous le nom `DB`.

Pour installer les sources sur une machine de développement :

```bash
cd code-source-complet
corepack enable
pnpm install --frozen-lockfile
pnpm build
```

Le projet déclare Node.js >= 22.13.0 et pnpm 11.25.0 dans `package.json`. Il faut installer ces outils avant d’exécuter les commandes. Le dossier `node_modules` n’est pas inclus ; les versions sont décrites dans `pnpm-lock.yaml`.

Pour publier cette partie chez un autre hébergeur, une adaptation de la configuration est nécessaire :

1. Utiliser un environnement compatible Cloudflare Workers ou porter les routes serveur vers votre hébergeur.
2. Créer une base D1 et appliquer les migrations du dossier `drizzle/`. Renseigner son véritable identifiant dans la configuration du nouvel environnement ; l’identifiant de développement dans `vite.config.ts` n’est pas une base de production.
3. Configurer côté serveur deux secrets : `ANALYTICS_SIGN_KEY` pour signer les sessions et `ANALYTICS_READ_KEY` pour protéger la lecture. Aucun secret réel n’est inclus dans cette archive. Ne jamais les placer dans les fichiers publics.
4. Ajouter votre nouveau domaine HTTPS aux origines autorisées dans `lib/analytics-core.mjs`.
5. Adapter l’intégration de déploiement spécifique à ChatGPT Sites (`.openai/hosting.json`, `build/sites-vite-plugin.ts` et les fichiers associés). Le manifeste d’origine est conservé pour fidélité, pas comme une configuration universelle pour tous les hébergeurs.
6. Si vous voulez continuer à utiliser le dashboard privé existant, son proxy devra pointer vers le nouveau domaine et utiliser la même clé de lecture. Ce dashboard constitue un projet séparé et n’est pas inclus dans cet export du site principal.

Les bases de données en ligne, l’historique des visiteurs, les droits d’accès de la plateforme et les clés privées ne font pas partie des fichiers du site. Cet export contient le code et les migrations du module de statistiques, pas une sauvegarde de ses données en production. Aucun site n’a été redéployé ou modifié pour produire cette archive.

## Médias inclus

- `assets/hero-cinema.mp4` : vidéo d’arrière-plan.
- `assets/hero-cinema.webp` : image de repli de la vidéo.
- `assets/elixir.webp` : affiche ÉLIXIR.
- `assets/moon-killing.webp` : visuel Moon Killing.
- `assets/origie-drama.webp` : visuel ORIGIE DRAMA.

Les médias sont présents dans chacun des deux dossiers pour rendre la copie publique et le projet source indépendants. Cela n’ajoute pas de nouveaux films au catalogue : il s’agit de tous les médias effectivement présents dans la version exportée.

## Vérifications effectuées

- Correspondance avec la révision Git indiquée ci-dessus et espace source sans modification locale.
- Présence des ressources locales référencées par les trois pages HTML.
- Présence et intégrité de la vidéo et des images dans le ZIP.
- Intégrité CRC de tous les fichiers de l’archive.

Le redéploiement sur votre futur hébergement n’a pas été effectué ni testé lors de cet export. Le README du projet d’origine, dans `code-source-complet/README.md`, est également conservé.
